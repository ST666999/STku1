"""全局配置与环境变量"""
import os
from dataclasses import dataclass
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()


@dataclass
class AgentConfig:
    """Agent总配置"""
    llm_model: str = os.getenv("LLM_MODEL", "gpt-4o-mini")
    llm_api_key: str = os.getenv("OPENAI_API_KEY", "")
    llm_base_url: str = os.getenv("OPENAI_BASE_URL", "")
    monitor_interval: int = int(os.getenv("MONITOR_INTERVAL", "300"))
    data_sources: list = None
    wecom_webhook: str = os.getenv("WECOM_WEBHOOK", "")
    email_smtp_host: str = os.getenv("EMAIL_SMTP_HOST", "")
    email_from: str = os.getenv("EMAIL_FROM", "")
    email_password: str = os.getenv("EMAIL_PASSWORD", "")
    max_iterations: int = int(os.getenv("MAX_ITERATIONS", "10"))
    enable_supervisor: bool = os.getenv("ENABLE_SUPERVISOR", "true").lower() == "true"
    
    def __post_init__(self):
        if self.data_sources is None:
            self.data_sources = [
                {"name": "metrics_db", "type": "postgres", "dsn": os.getenv("DB_DSN", "")},
                {"name": "system_monitor", "type": "api", "url": os.getenv("MONITOR_API_URL", "")},
            ]


config = AgentConfig()
