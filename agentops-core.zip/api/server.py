from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import Dict, Any, Optional
import uvicorn
from ..core.orchestrator import Orchestrator
from ..config import config

app = FastAPI(title="AgentOps Core")
orchestrator = Orchestrator(config.__dict__)


class RunRequest(BaseModel):
    instruction: str
    context: Optional[Dict[str, Any]] = None


class RunResponse(BaseModel):
    session_id: str
    status: str
    total_tasks: int
    completed: int
    failed: int
    results: Dict[str, Any]


@app.post("/run")
async def run_workflow(request: RunRequest):
    result = await orchestrator.process_instruction(request.instruction, request.context)
    return RunResponse(**result)


@app.get("/health")
async def health():
    return {"status": "healthy"}


def run_server():
    uvicorn.run("api.server:app", host="0.0.0.0", port=8000, reload=True)
