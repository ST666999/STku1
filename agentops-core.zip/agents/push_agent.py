"""推送Agent - 多渠道分发"""
from typing import Dict, Any
from datetime import datetime
from ..tools.notify_tools import send_wecom_message, send_email


class PushAgent:
    name = "push_agent"
    
    def __init__(self, config=None):
        self.config = config or {}
    
    async def execute(self, state, task) -> Dict[str, Any]:
        params = task.params
        channels = params.get("channels", ["wecom"])
        content = params.get("content", "")
        results = {}
        for ch in channels:
            if ch == "wecom":
                results[ch] = await send_wecom_message(self.config.get("wecom_webhook"), content)
            elif ch == "email":
                results[ch] = await send_email(self.config.get("email_default_to"), "运营报告", content, self.config)
        return {"type": "push", "results": results}
