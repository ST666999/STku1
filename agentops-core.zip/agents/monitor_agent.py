"""监控Agent - 负责数据监控和指标采集"""
from typing import Dict, Any, List
from datetime import datetime
from ..tools.data_tools import query_database, call_api, get_system_metrics
from ..workflow.states import AgentState, Task


class MonitorAgent:
    name = "monitor_agent"
    description = "负责监控系统指标、数据库变化和业务数据"
    
    def __init__(self, config: Dict[str, Any] = None):
        self.config = config or {}
        
    async def execute(self, state: AgentState, task: Task) -> Dict[str, Any]:
        params = task.params
        monitor_type = params.get("type", "general")
        
        if monitor_type == "database":
            return await self._monitor_database(params)
        elif monitor_type == "api":
            return await self._monitor_api(params)
        elif monitor_type == "system":
            return await self._monitor_system(params)
        else:
            return await self._monitor_general(params)
    
    async def _monitor_database(self, params: Dict) -> Dict:
        query = params.get("query")
        result = await query_database(query, params.get("dsn"))
        return {"type": "database", "timestamp": datetime.now().isoformat(), "data": result.get("rows", [])}
    
    async def _monitor_api(self, params: Dict) -> Dict:
        url = params.get("url")
        result = await call_api(url, method="GET")
        return {"type": "api", "timestamp": datetime.now().isoformat(), "healthy": result.get("status_code") == 200, "data": result.get("data")}
    
    async def _monitor_system(self, params: Dict) -> Dict:
        metrics = await get_system_metrics()
        alerts = []
        cpu_threshold = params.get("cpu_threshold", 80)
        if metrics.get("cpu_percent", 0) > cpu_threshold:
            alerts.append(f"CPU high: {metrics['cpu_percent']}%")
        return {"type": "system", "timestamp": datetime.now().isoformat(), "metrics": metrics, "alerts": alerts}
    
    async def _monitor_general(self, params: Dict) -> Dict:
        return {"timestamp": datetime.now().isoformat(), "data": {"status": "ok"}}
