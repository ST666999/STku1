"""报告Agent - 生成结构化报告"""
from typing import Dict, Any
from datetime import datetime


class ReportAgent:
    name = "report_agent"
    
    async def execute(self, state, task) -> Dict[str, Any]:
        params = task.params
        analysis_data = params.get("analysis_data", {})
        report_format = params.get("format", "markdown")
        
        if report_format == "markdown":
            content = self._generate_markdown(analysis_data, params)
        else:
            content = str(analysis_data)
        
        return {"type": "report", "format": report_format, "content": content, "timestamp": datetime.now().isoformat()}
    
    def _generate_markdown(self, data, params):
        title = params.get("title", "运营报告")
        date = datetime.now().strftime("%Y-%m-%d")
        return f"# {title}\n\n**日期**: {date}\n\n## 核心摘要\n{data.get('summary', '无')}"
