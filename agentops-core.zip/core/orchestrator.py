"""总控Agent - 任务拆解与调度"""
import uuid
from typing import Dict, Any, List
from ..workflow.states import AgentState, Task
from ..agents.monitor_agent import MonitorAgent
from ..agents.analysis_agent import AnalysisAgent
from ..agents.report_agent import ReportAgent
from ..agents.push_agent import PushAgent


class Orchestrator:
    def __init__(self, config=None, llm=None):
        self.config = config or {}
        self.llm = llm
        self.agents = {
            "monitor": MonitorAgent(config),
            "analysis": AnalysisAgent(llm),
            "report": ReportAgent(),
            "push": PushAgent(config)
        }
    
    async def process_instruction(self, instruction: str, context: Dict = None) -> Dict:
        session_id = str(uuid.uuid4())
        state = AgentState(session_id=session_id, instruction=instruction, context=context or {})
        tasks = self._decompose_instruction(instruction)
        for t in tasks:
            state.add_task(t)
        
        while True:
            task = state.get_next_task()
            if not task:
                break
            agent = self.agents.get(task.type)
            if agent:
                result = await agent.execute(state, task)
                state.update_task_result(task.id, result, "completed")
            else:
                state.update_task_result(task.id, {"error": "unknown agent"}, "failed")
        
        return {"session_id": session_id, "status": "completed", "total_tasks": len(state.tasks), "completed": state.completed_count, "failed": state.failed_count, "results": state.context}
    
    def _decompose_instruction(self, instruction: str) -> List[Task]:
        tasks = []
        inst_lower = instruction.lower()
        if any(k in inst_lower for k in ["监控", "monitor"]):
            tasks.append(Task(id=str(uuid.uuid4()), type="monitor", description="数据监控"))
        if any(k in inst_lower for k in ["分析", "analyze"]):
            tasks.append(Task(id=str(uuid.uuid4()), type="analysis", description="数据分析"))
        if any(k in inst_lower for k in ["报告", "report"]):
            tasks.append(Task(id=str(uuid.uuid4()), type="report", description="生成报告"))
        if any(k in inst_lower for k in ["推送", "push"]):
            tasks.append(Task(id=str(uuid.uuid4()), type="push", description="推送消息"))
        if not tasks:
            tasks = [Task(id=str(uuid.uuid4()), type="monitor", description="默认监控")]
        return tasks
