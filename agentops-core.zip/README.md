# AgentOps Core - 多Agent协同运营自动化系统

## 简介
基于 LangGraph + FastAPI 的多智能体协作框架，实现运营自动化闭环。

## 快速开始
1. 安装依赖：`pip install -r requirements.txt`
2. 配置环境：复制 `.env.example` 为 `.env` 并填入你的 API Key 和推送渠道
3. 启动服务：`python -m api.server`
4. 调用 API：`POST http://localhost:8000/run`

## 目录结构
- `agents/` - 四大专业 Agent
- `core/` - 总控与监督
- `workflow/` - LangGraph 工作流定义
- `tools/` - RPA、数据、通知工具集
- `api/` - FastAPI 服务入口
- `tests/` - 单元测试

## 许可证
MIT
