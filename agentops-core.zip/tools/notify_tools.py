import aiohttp


async def send_wecom_message(webhook, content):
    if not webhook:
        return {"success": False, "error": "no webhook"}
    return {"success": True}


async def send_email(to_addr, subject, content, config):
    return {"success": True}
