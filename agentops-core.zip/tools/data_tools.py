import aiohttp
import asyncio
from datetime import datetime


async def query_database(query, dsn=None):
    return {"rows": [], "metrics": {}}


async def call_api(url, method="GET", headers=None, data=None):
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as resp:
            return {"status_code": resp.status, "data": await resp.json()}
    
    
async def get_system_metrics():
    import random
    return {"cpu_percent": random.randint(10, 80), "memory_percent": random.randint(20, 70)}
