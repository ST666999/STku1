import os
from datetime import datetime


async def run_rpa_task(config: dict):
    return {"status": "ok"}


async def take_screenshot(output_path=None):
    if not output_path:
        output_path = f"screenshots/screenshot_{datetime.now().strftime('%Y%m%d_%H%M%S')}.png"
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    return output_path
