from typing import Dict, Any, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
import uuid


@dataclass
class Task:
    id: str
    type: str
    description: str
    priority: int = 1
    params: Dict[str, Any] = field(default_factory=dict)
    assigned_agent: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    status: str = "pending"
    created_at: datetime = field(default_factory=datetime.now)


@dataclass
class AgentState:
    session_id: str
    instruction: str
    tasks: List[Task] = field(default_factory=list)
    context: Dict[str, Any] = field(default_factory=dict)
    messages: List[Dict[str, str]] = field(default_factory=list)
    current_task_index: int = 0
    completed_count: int = 0
    failed_count: int = 0
    status: str = "initializing"
    
    def add_task(self, task: Task):
        self.tasks.append(task)
    
    def get_next_task(self) -> Optional[Task]:
        pending = [t for t in self.tasks if t.status == "pending"]
        if pending:
            pending.sort(key=lambda x: x.priority)
            return pending[0]
        return None
    
    def update_task_result(self, task_id: str, result: Dict[str, Any], status: str = "completed"):
        for task in self.tasks:
            if task.id == task_id:
                task.result = result
                task.status = status
                break
        if status == "completed":
            self.completed_count += 1
        elif status == "failed":
            self.failed_count += 1
