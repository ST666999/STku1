from langgraph.graph import StateGraph, END
from langgraph.checkpoint import MemorySaver
from typing import TypedDict, Literal


class GraphState(TypedDict):
    session_id: str
    instruction: str
    tasks: list
    context: dict
    current_task_index: int
    completed_count: int
    failed_count: int
    status: str


def create_workflow(config=None, llm=None):
    workflow = StateGraph(GraphState)
    # 简化的图，实际可扩展
    workflow.add_node("monitor", lambda state: state)
    workflow.set_entry_point("monitor")
    workflow.add_edge("monitor", END)
    memory = MemorySaver()
    return workflow.compile(checkpointer=memory)
